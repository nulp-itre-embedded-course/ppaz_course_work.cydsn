#include <project.h>

const uint16 INPUT_SIGNAL_SIZE = 16;

uint16 input_signal[16] = {
2040,
2820,
3482,
3924,
4080,
3924,
3482,
2820,
2040,
1259,
597,
155,
0,
155,
597,
1259,
};

