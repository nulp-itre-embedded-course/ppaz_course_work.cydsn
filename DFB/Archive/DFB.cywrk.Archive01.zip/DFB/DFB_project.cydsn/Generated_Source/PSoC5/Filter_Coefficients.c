#include "Filter.h"
#include "Filter_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelABiquadCoefficients Filter_ChannelABiquadCoefficients

/* Number of Biquad sections are: 1 */

const uint8 CYCODE Filter_ChannelABiquadCoefficients[Filter_BIQUAD_A_SIZE] = 
{
 /* Coefficients of Section 0 */
 0x7Eu, 0xABu, 0x04u, 0x00u, /* Section(0)_A0, 0.0729670524597168 */

 0x00u, 0x00u, 0x00u, 0x00u, /* Section(0)_A1, 0 */

 0x82u, 0x54u, 0xFBu, 0x00u, /* Section(0)_A2, -0.0729670524597168 */

 0xB7u, 0x4Bu, 0x60u, 0x00u, /* Section(0)_B1, -1.50462126731873 */

 0xBEu, 0x56u, 0xC9u, 0x00u, /* Section(0)_B2, 0.854080677032471 */
};

